package worldwanderer.backend.entity;

public enum Role {
    ADMIN,
    USER,
    GUEST
}
