import React from "react";

interface Props {}

function TripListComponent(props: Props) {
  return <></>;
}

export default TripListComponent;
